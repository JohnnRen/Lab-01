#include <stdio.h>

void foo_func(int x) {
	printf("foo_func %d\n", x);
}