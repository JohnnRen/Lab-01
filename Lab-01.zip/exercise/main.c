#include "foo/foo.h"
#include "bar/bar.h"

int main() {
	foo_func(100);
	bar_func("hello bar");
}